<?php
/*
Template Name: Only Audio
*/

global $THEMEREX_only_audio;
$THEMEREX_only_audio = true;

get_template_part('blog');
?>