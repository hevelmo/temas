<?php
/*
Template Name: Only Video
*/

global $THEMEREX_only_video;
$THEMEREX_only_video = true;

get_template_part('blog');
?>