<?php
/*
Template Name: Only Gallery
*/

global $THEMEREX_only_gallery;
$THEMEREX_only_gallery = true;

get_template_part('blog');
?>